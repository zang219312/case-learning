<template>
  <div>goods</div>
</template>

<script setup></script>

<style lang="scss" scoped></style>
