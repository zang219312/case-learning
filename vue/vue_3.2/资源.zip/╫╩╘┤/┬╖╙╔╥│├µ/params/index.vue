<template>
  <div>params</div>
</template>

<script setup></script>

<style lang="scss" scoped></style>
